from django.shortcuts import render
from django.http import HttpResponse
import logging
#import authlib
import jwt
import openedx.core.djangoapps.user_api.views as user_api_view
import requests
import django.middleware.csrf
from django.views.decorators.csrf import csrf_exempt, csrf_protect, ensure_csrf_cookie
from django.utils.decorators import method_decorator
from django.shortcuts import redirect
import re
secret = '$ecRet@3#$2958GPIs!1'

from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.generics import GenericAPIView

from univerapi.models import Univeruser
from random import randint
import json
from student.models import User
import time
from django.db import connection
from django.contrib.sites.models import Site
from django.conf import settings
from django.http import JsonResponse

class UniverView(GenericAPIView):

    def createuser():
        return 123

    @method_decorator(csrf_protect)
    def post(self, request):

        # TEST user
        #exist_user = User.objects.get(email='hakymova.tyyshtyq642@kaznu.kz')
        #return HttpResponse(repr(exist_user))
        # TEST user

        auth = request.POST.get('auth')
        #auth = auth.split("auth=")[1]
        encoded_jwt = request.GET.get('auth')
        decoded = jwt.decode(encoded_jwt, "$ecRet@3#$2958GPIs!1", algorithms=["HS256"])

        new_user = Univeruser()
        #new_user = Univeruser(edx_id = 0, edx_pass=decoded['upwd'], univer_id = decoded['uname'])
        '''
        new_user.edx_pass=decoded['upwd']
        new_user.univer_id = decoded['uname']
        new_user.save()
        '''
        created_user = ''
        created_user_email = ''
        try:
            exist_user = Univeruser.objects.get(univer_id=decoded['uname'])
            
            return HttpResponse('user exist')

        except:
            created_user = decoded['uname'].split(".")[0]+str(randint(0, 1000))
            created_user_email = decoded['uname']+str(randint(0, 1000))+'@kaznu.kz'
            multipart_form_data = {
                'email': (None, created_user_email),
                'password': (None, decoded['upwd'][:75]),
                'name': (None, decoded['uname']),
                'username': (None, created_user),
                'level_of_education': (None, 'b'),
                'gender': (None, 'o'),
                'year_of_birth': (None, '1995'),
                'honor_code': (None, 'true'),
            }
            client = requests.session()
            client.get('http://192.168.199.128')
            csrftoken = client.cookies['csrftoken']
            login_data = dict(csrfmiddlewaretoken=csrftoken, next='/form_call/')
            coky = 'csrftoken='+csrftoken
            headers = {
               'X-CSRFToken': csrftoken,
               'Cookie':coky
            }

            response = requests.post('http://192.168.199.128:8181/user_api/v1/account/registration/', data=login_data, files=multipart_form_data, headers=headers)

            #new_user.edx_pass=decoded['upwd']
            #new_user.univer_id = decoded['uname']
            #new_user.save()
            json_data = json.loads(response.text)
            
            if ( ('success' in json_data) and (json_data['success'] == True)):
                created_user_str = str(created_user)
                
                exist_user = None
                i = 0
                while i < 60:
                    try:  
                        exist_user = User.objects.get(username=created_user_str)
                        #exist_user = User.objects.raw('SELECT * FROM auth_user')
                        User.refresh_from_db()
                        break
                    except:
                        i += 1    
                        time.sleep(1)
                        
                out_html=''    
                query = """SELECT id, username FROM auth_user where username LIKE '""" + "%%" + "hakymova" + "%%" + """'""" 
                query2 = """SELECT id, username FROM auth_user where username = '""" + created_user_str + """'"""


                return HttpResponse(repr(exist_user)) 

                # raw sql
                time.sleep(10)
                cursor = connection.cursor()
                row = None
                sql = 'SELECT id, username FROM auth_user'
                try:
                    cursor.execute(str(query2))
                    row = cursor.fetchall()
                    return HttpResponse(repr(row)) 
                except Exception as e:
                    cursor.close
                    return HttpResponse('error =' + str(e)) 
                # raw sql

                return HttpResponse(repr(cursor)) 
                #time.sleep(20)
                #for p in User.objects.raw(query):
                    #User.refresh_from_db()
                #    out_html += str(p.username) + '\n'
                #exist_user = User.objects.raw(str(query))
                #exist_user = User.objects.get(id=51808)
                #return HttpResponse(str(created_user_str) + ' = ' + repr(exist_user) + str(i) + str(out_html))
                #return HttpResponse( str(out_html))                
            else:
                return HttpResponse('no registration')    
            
            return HttpResponse((json_data['success']))


        #check_user = Univeruser.objects.get(univer_id=decoded['uname'])

        return HttpResponse(repr(exist_user))

        multipart_form_data = {
	        'email': (None, 'dl@kaznu.kz'),
	        'password': (None, 'DlGao3wo'),
	        'remember': (None, 'true')
        }
        client = requests.session()
        client.get('http://192.168.199.128')
        csrftoken = client.cookies['csrftoken']
        login_data = dict(csrfmiddlewaretoken=csrftoken, next='/form_call/')
        coky = 'csrftoken='+csrftoken
        headers = {
            'X-CSRFToken': csrftoken,
            'Cookie':coky
        }

        response = requests.post('http://192.168.199.128/user_api/v1/account/login_session/', data=login_data, files=multipart_form_data, headers=headers)

        headers2 = response.headers
        
        csrfToken = re.search(r'csrftoken=(\w+);', headers2['Set-Cookie'])
        sessionid = re.search(r'sessionid="(\S+)";', headers2['Set-Cookie'])


        cookies2 = {
        '_ga': 'GA1.1.1602606957.1602045613',
        'experiments_is_enterprise': 'false',
        'openedx-language-preference': 'ru',
        'csrftoken': csrfToken.group(1),
        'edxloggedin': 'true',
        'sessionid': sessionid.group(1),
        'edx-user-info': '{\\"username\\": \\"staff\\"\\054 \\"version\\": 1\\054 \\"enrollmentStatusHash\\": \\"ace9f6124341dc7692d41de5b91bff7d\\"\\054 \\"header_urls\\": {\\"learner_profile\\": \\"http://192.168.199.128/u/staff\\"\\054 \\"resume_block\\": \\"http://192.168.199.128/user_api/v1/account/login_session/\\"\\054 \\"logout\\": \\"http://192.168.199.128/logout\\"\\054 \\"account_settings\\": \\"http://192.168.199.128/account/settings\\"}}',
        }

        headers3 = {
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Referer': 'http://192.168.199.128/login?next=%2F',
        'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
        'sec-gpc': '1',
        }

        response = requests.get('http://192.168.199.128', headers=headers3, cookies=cookies2, verify=False)
        return HttpResponse(response)

        #return HttpResponse(request.POST['csrf'])

    @method_decorator(ensure_csrf_cookie)
    def get(self, request):
    	#return HttpResponse(repr(django.middleware.csrf.get_token(request)))
        #return render(request, 'univerapi/login.html')
        # TEST user
        #exist_user = User.objects.get(email='hakymova.tyyshtyq642@kaznu.kz')
        #return HttpResponse(repr(exist_user))
        # TEST user
        current_site = settings.LMS_ROOT_URL
        

        auth = request.POST.get('auth')
        #auth = auth.split("auth=")[1]
        encoded_jwt = request.GET.get('auth')
        decoded = jwt.decode(encoded_jwt, secret, algorithms=["HS256"])

        #return HttpResponse(decoded['upwd'][:75])
        #new_user = Univeruser()
        #new_user = Univeruser(edx_id = 0, edx_pass=decoded['upwd'], univer_id = decoded['uname'])
        '''
        new_user.edx_pass=decoded['upwd']
        new_user.univer_id = decoded['uname']
        new_user.save()
        '''
        created_user = ''
        created_user_email = ''
        try:
            exist_user = Univeruser.objects.get(univer_id=decoded['uname'])
            
            return render(request, 'univerapi/redirect.html')
            #return HttpResponse('user exist')

        except:
            #created_user = decoded['uname'].split(".")[0]+str(randint(0, 1000))
            created_user = decoded['uname'].split(".")[0]+"_"+decoded['uname'].split(".")[1]
            created_user_email = decoded['uname']+str(randint(0, 1000))+'@kaznu.kz'
            multipart_form_data = {
                'email': (None, created_user_email),
                'password': (None, decoded['upwd'][:75]),
                'name': (None, decoded['uname']),
                'username': (None, created_user),
                'level_of_education': (None, 'b'),
                'gender': (None, 'o'),
                'year_of_birth': (None, '1995'),
                'honor_code': (None, 'true'),
            }
            client = requests.session()
            client.get(current_site)
            csrftoken = client.cookies['csrftoken']
            login_data = dict(csrfmiddlewaretoken=csrftoken, next='/form_call/')
            coky = 'csrftoken='+csrftoken
            headers = {
               'X-CSRFToken': csrftoken,
               'Cookie':coky
            }
            count_try = 0
            while True:
                response = requests.post(current_site + '/user_api/v1/account/registration/', data=login_data, files=multipart_form_data, headers=headers)
                json_data = json.loads(response.text)
                if ( ('success' in json_data) and (json_data['success'] == True)):
                    break
                if ( ('username' in json_data) ):    
                    if "existing account" in str(json_data): 
                        #new_user = Univeruser()
                        #new_user = Univeruser(edx_id = created_user, edx_pass=0, univer_id = decoded['uname'])  
                        #new_user.edx_username = created_user
                        #new_user.edx_id=0
                        #new_user.edx_pass='0'
                        #new_user.univer_id = decoded['uname']
                        #new_user.save()

                        return render(request, 'univerapi/redirect.html')
                time.sleep(1)   
                count_try += 1
                if (count_try == 20):
                    return JsonResponse(json_data)       
            
            if ( ('success' in json_data) and (json_data['success'] == True)):
                new_user = Univeruser()
                new_user.edx_username = created_user
                new_user.edx_id=0
                new_user.edx_pass='0'
                new_user.univer_id = decoded['uname']
                new_user.save()                

                return render(request, 'univerapi/redirect.html')

                created_user_str = str(created_user)
                
                exist_user = None
                i = 0
                while i < 60:
                    try:  
                        exist_user = User.objects.get(username=created_user_str)
                        #exist_user = User.objects.raw('SELECT * FROM auth_user')
                        User.refresh_from_db()
                        break
                    except:
                        i += 1    
                        time.sleep(1)
                        
                out_html=''    
                query = """SELECT id, username FROM auth_user where username LIKE '""" + "%%" + "hakymova" + "%%" + """'""" 
                query2 = """SELECT id, username FROM auth_user where username = '""" + created_user_str + """'"""


                return HttpResponse(repr(exist_user)) 

                # raw sql
                time.sleep(10)
                cursor = connection.cursor()
                row = None
                sql = 'SELECT id, username FROM auth_user'
                try:
                    cursor.execute(str(query2))
                    row = cursor.fetchall()
                    return HttpResponse(repr(row)) 
                except Exception as e:
                    cursor.close
                    return HttpResponse('error =' + str(e)) 
                # raw sql

                return HttpResponse(repr(cursor))     
            else:
                return HttpResponse('no registration')

#@method_decorator(csrf_protect)
#method_decorator(csrf_protect)

def authview(request):
	return render(request, 'univerapi/index.html')
	#return HttpResponse('auth')

# check activated
def authview_check(request):
    auth = request.POST.get('auth')
    auth = auth.split("auth=")[1]
    #encoded_jwt = request.GET.get('auth')
    #decoded = jwt.decode(encoded_jwt, "$ecRet@3#$2958GPIs!1", algorithms=["HS256"])
    #return HttpResponse('OK')
    encoded_jwt = auth
    decoded = jwt.decode(encoded_jwt, "$ecRet@3#$2958GPIs!1", algorithms=["HS256"])
    already_exist_user = decoded['uname']

    try:
        exist_user = Univeruser.objects.get(univer_id=decoded['uname'])
        exist_edx_user = User.objects.get(username=exist_user.edx_username)
        exist_edx_user.is_active = 1
        exist_edx_user.save()  
        #return render(request, 'univerapi/redirect.html')
        

    except:
        return JsonResponse({"success":"false"}) 

    #return HttpResponse('')
    return JsonResponse({"success":"true"}) 

@method_decorator(csrf_protect)
def test(request, *args, **kwargs):
    logger = logging.getLogger(__name__)
    logger.error("Test api")
    #logger.error(request)
    #logger.error(request.GET.get('auth'))
    #encoded_jwt = jwt.encode({"some": "payload"}, "secret", algorithm="HS256")

    #return HttpResponse(answer)
    # hash = eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1bmFtZSI6Imhha3ltb3ZhLnR5eXNodHlxIiwidXB3ZCI6IjA3NzdGMDk4MEIzMUE2MEZDRkVFQzlEQjNGOTFEOUI4RUVCQUU4NDQ0NjAwRTQ3MUQyMzEyQjYyNDA2MjVCNTZFM0Q0RDM5RDRBREYwMTg5N0QzQTEzMDkzRTcwRkU1NjRGMUJBRDZCOTIxMUE0NTAwODQxRDFFQzNFMkNGODcwIn0.QLCZHTM2ACm0byg77h0C7KpGwMxcxJuy-M96lQzc3Mk	

    #return HttpResponse(repr(args))

    client = requests.session()
    client.get('http://192.168.199.128')
    csrftoken = client.cookies['csrftoken']
    login_data = dict(csrfmiddlewaretoken=csrftoken, next='/form_call/')
    coky = 'csrftoken='+csrftoken
    headers = {
        'X-CSRFToken': csrftoken,
        'Cookie':coky
    }

    # register
    multipart_form_data_register = {
        'email': (None, 'hakymova.tyyshtyq@test11.ru'),
        'name': (None, 'hakymova.tyyshtyq'),
        'username': (None, 'hakymova11'),
        'password': (None, '988EBA1673B2F08F99F61719A2F8BC47791250B3A052DA2992D0148DE2D2E084C2E23E6E3C7'),
        'level_of_education': (None, 'hs'),
        'gender': (None, 'f'),
        'year_of_birth': (None, '1969'),
        'mailing_address': (None, ''),
        'goals': (None, ''),
        'honor_code': (None, 'true'),
        
    }
    response_register = requests.post('http://192.168.199.128/user_api/v1/account/registration/', data=login_data, files=multipart_form_data_register, headers=headers)

    return HttpResponse(repr(response_register))

    # /register

    multipart_form_data = {
	    'email': (None, 'dl@kaznu.kz'),
	    'password': (None, 'DlGao3wo'),
	    'remember': (None, 'false')
    }
    client = requests.session()
    client.get('http://192.168.199.128')
    csrftoken = client.cookies['csrftoken']
    login_data = dict(csrfmiddlewaretoken=csrftoken, next='/form_call/')
    coky = 'csrftoken='+csrftoken
    headers = {
        'X-CSRFToken': csrftoken,
        'Cookie':coky
    }
    # http://192.168.199.128/user_api/v1/account/login_session/
    # https://webhook.site/8bdb471b-3d63-46c2-b788-79f7398144e6
    






    

    response = requests.post('http://192.168.199.128/user_api/v1/account/login_session/', data=login_data, files=multipart_form_data, headers=headers)

    return HttpResponse(repr(request.GET))

    #client.get('http://192.168.199.128:8181')
    #session_key = client.cookies['sessionid']
    
    
    #edx_auth = user_api_view.LoginSessionView()
    #testauth = edx_auth.post(request)

    headers2 = response.headers
    #home = requests.get('http://192.168.199.128/dashboard', headers=headers2)
    #home = HttpResponse(status=302)
    #home['Location'] = 'http://192.168.199.128/'
    csrfToken = re.search(r'csrftoken=(\w+);', headers2['Set-Cookie'])
    sessionid = re.search(r'sessionid="(\S+)";', headers2['Set-Cookie'])





    cookies2 = {
    '_ga': 'GA1.1.1602606957.1602045613',
    'experiments_is_enterprise': 'false',
    'openedx-language-preference': 'ru',
    'csrftoken': csrfToken.group(1),
    'edxloggedin': 'true',
    'sessionid': sessionid.group(1),
    'edx-user-info': '{\\"username\\": \\"staff\\"\\054 \\"version\\": 1\\054 \\"enrollmentStatusHash\\": \\"ace9f6124341dc7692d41de5b91bff7d\\"\\054 \\"header_urls\\": {\\"learner_profile\\": \\"http://192.168.199.128/u/staff\\"\\054 \\"resume_block\\": \\"http://192.168.199.128/user_api/v1/account/login_session/\\"\\054 \\"logout\\": \\"http://192.168.199.128/logout\\"\\054 \\"account_settings\\": \\"http://192.168.199.128/account/settings\\"}}',
    }

    headers3 = {
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Referer': 'http://192.168.199.128/login?next=%2F',
    'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
    'sec-gpc': '1',
    }

    response = requests.get('http://192.168.199.128/dashboard', headers=headers3, cookies=cookies2, verify=False)
    return HttpResponse(response)







    return HttpResponse(sessionid.group(1))

    
    #home = redirect('http://192.168.199.128')
    #return home

    try: 
        #test = edx_auth.post(request)
        test = 0
    except Exception as e:
    	return HttpResponse(e.message)

    hash = request.GET.get('auth')
    try: 
        answer = jwt.decode(hash, secret, algorithms=["HS256"])
    except Exception as e:
    	return HttpResponse(e.message)

    #return HttpResponse(repr(request))
    return HttpResponse(repr(response.headers))
