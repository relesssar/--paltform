from django.apps import AppConfig


class UniverapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'univerapi'
